import { useState } from 'react'
import Homepage from './pages/Homepage'
import './global.css';

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
    <Homepage/>
      
    </>
  )
}

export default App
