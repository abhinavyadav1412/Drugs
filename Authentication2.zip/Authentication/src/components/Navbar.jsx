import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import './Navbar.css'; // Import your custom CSS

const Navbar = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isServicesOpen, setIsServicesOpen] = useState(false);
  const dropdownRef = useRef(null);
  const servicesTimeoutRef = useRef(null);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsServicesOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleServicesHover = (open) => {
    if (servicesTimeoutRef.current) {
      clearTimeout(servicesTimeoutRef.current);
    }
    servicesTimeoutRef.current = setTimeout(() => {
      setIsServicesOpen(open);
    }, open ? 100 : 300);
  };

  return (
    <nav className="navbar">
      <div className="navbar-container">
        <div className="navbar-left">
          <motion.a 
            href="#" 
            className="logo" 
            whileHover={{ scale: 1.05 }}
            transition={{ type: 'spring', stiffness: 300 }}
          >
            CarePulse
          </motion.a>

          <div className="desktop-menu">
            <NavLink href="#">Home</NavLink>
            <NavLink href="#">About</NavLink>

            <div 
              className="dropdown" 
              ref={dropdownRef}
              onMouseEnter={() => handleServicesHover(true)}
              onMouseLeave={() => handleServicesHover(false)}
            >
              <button className="dropdown-button">
                <span>Services</span>
                <motion.span
                  animate={{ rotate: isServicesOpen ? 180 : 0 }}
                  transition={{ duration: 0.2 }}
                >
                  <ChevronDown />
                </motion.span>
              </button>

              <AnimatePresence>
                {isServicesOpen && (
                  <motion.div
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    transition={{ duration: 0.2 }}
                    className="dropdown-menu"
                  >
                    <DropdownLink href="#">Health Monitoring</DropdownLink>
                    <DropdownLink href="#">Patient Analytics</DropdownLink>
                    <DropdownLink href="#">Remote Care</DropdownLink>
                    <DropdownLink href="#">Clinical Support</DropdownLink>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            <NavLink href="#">Contact</NavLink>
          </div>
        </div>

        <div className="navbar-right">
          <motion.a
            href="#"
            className="cta-button"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            Get Started
          </motion.a>

          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="mobile-menu-button"
          >
            {isMenuOpen ? <XIcon /> : <MenuIcon />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.2 }}
            className="mobile-menu"
          >
            <MobileNavLink href="#">Home</MobileNavLink>
            <MobileNavLink href="#">About</MobileNavLink>

            <div className="mobile-dropdown">
              <button 
                onClick={() => setIsServicesOpen(!isServicesOpen)}
                className="mobile-dropdown-button"
              >
                <span>Services</span>
                <motion.span
                  animate={{ rotate: isServicesOpen ? 180 : 0 }}
                  transition={{ duration: 0.2 }}
                >
                  <ChevronDown />
                </motion.span>
              </button>

              <AnimatePresence>
                {isServicesOpen && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    transition={{ duration: 0.2 }}
                    className="mobile-dropdown-menu"
                  >
                    <MobileDropdownLink href="#">Health Monitoring</MobileDropdownLink>
                    <MobileDropdownLink href="#">Patient Analytics</MobileDropdownLink>
                    <MobileDropdownLink href="#">Remote Care</MobileDropdownLink>
                    <MobileDropdownLink href="#">Clinical Support</MobileDropdownLink>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            <MobileNavLink href="#">Contact</MobileNavLink>
            <MobileCTALink href="#">Get Started</MobileCTALink>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

// Sub-components
const NavLink = ({ href, children }) => (
  <motion.a
    href={href}
    className="nav-link"
    whileHover={{ scale: 1.05 }}
  >
    {children}
  </motion.a>
);

const MobileNavLink = ({ href, children }) => (
  <a href={href} className="mobile-nav-link">
    {children}
  </a>
);

const DropdownLink = ({ href, children }) => (
  <a href={href} className="dropdown-link">
    {children}
  </a>
);

const MobileDropdownLink = ({ href, children }) => (
  <a href={href} className="mobile-dropdown-link">
    {children}
  </a>
);

const MobileCTALink = ({ href, children }) => (
  <motion.a
    href={href}
    className="mobile-cta-link"
    whileHover={{ scale: 1.02 }}
    whileTap={{ scale: 0.98 }}
  >
    {children}
  </motion.a>
);

// Icons
const MenuIcon = () => (
  <svg className="icon" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
  </svg>
);

const XIcon = () => (
  <svg className="icon" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
  </svg>
);

const ChevronDown = () => (
  <svg className="icon-small" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
  </svg>
);

export default Navbar;
